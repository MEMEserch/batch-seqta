@Echo off
title admin utility service
for %%f in (*.noadmin) do (
	goto noadminmode
)
for %%f in (*.dev) do (
	for %%f in (*.reset) do (
		goto package
	)
	goto run
)
color 0a
cls
echo =========permissions-not-met=========
echo this service requires administrator
echo perms you can turn them on in the
echo app
echo -------------------------------------
pause > nul
goto q

:run
color 0a
cls
echo type help for a list of commands or press Q to exit;
timeout 5 > nul
cls
timeout 1 > nul
:menu
echo.
SET INPUT=
SET /P INPUT=C;
	IF /I '%INPUT%'=='help' goto help
	IF /I '%INPUT%'=='addexit' goto addexit
	IF /I '%INPUT%'=='Q' goto q
	IF /I '%INPUT%'=='toggledev' goto devstuff
	IF /I '%INPUT%'=='package' goto package	
	
echo.
echo please enter a valid command
goto menu

:package
echo WARNING THIS APPLICATION WILL DELLET ALL USER DATA
echo press any key to run or close this application
pause > nul
cls
echo THIS IS THE LAST WARNING
pause > nul
echo clearing data. . .
echo ------------------
echo [][][][
echo ------------------
del url.bat
del log.log
del real.com
del mode.menuC
del enabledscript.runstart
del 
cls
echo clearing data. . .
echo ------------------
echo [][][][][][][][][]
echo ------------------
del mode.menuT
del real.setedup
del real.officechoice
del urlw.bat
del pass.dev
del admin.reset
for %%f in (*.png) do (
	del %%f
)
cls
color 9f
echo clearing data. . .
echo ------------------
echo   TASK COMPLETED
echo ------------------
pause > nul
goto q

:help
echo.
echo help            -            I seriously do not think you need an explanation
echo addexit         -            ensure the batch files that redirect you to seqta automatically close when opened
echo toggledev       -            turn dev mode off effectively locking this service until its turned back on through the app
echo Q               -            realise that no one uses batch in the big 2026 and leave
echo package         -            dellete all user data
goto menu

:devstuff
echo junk file >> admin.turnonadmin
echo junk file >> admin.noadmin
start admin_utility_service.bat
goto q

:addexit
echo junk file >> admin.addexit
echo junk file >> admin.noadmin
start admin_utility_service.bat
goto q


:noadminmode
for %%f in (*.addexit) do (
	echo adding exits. . .
	echo exit >> url.bat
	echo exit >> urlw.bat
	echo delleting junk files to prevent glitching. . .
	del admin.noadmin
	del	admin.addexit
	timeout 1 > nul
	goto exit
)
for %%f in (*.turnonadmin) do (
	for %%f in (*.dev) do (
		echo press enter to disable admin. . .
		pause > nul
		del pass.dev
		echo it has been disabled. . .
		del admin.noadmin
		del	admin.turnonadmin
		timeout 1 > nul
		goto exit
	)
	echo press enter to enable admin. . .
	pause > nul
	echo idk what your doing reading this >> pass.dev
	echo it has been enabled. . .
	del admin.noadmin
	del	admin.turnonadmin
	timeout 1 > nul
	goto exit
)
cls
echo a error has occured and junk files have been detected
echo delleting them in 5 seconds
timeout 1 > nul
cls
echo a error has occured and junk files have been detected
echo delleting them in 4 seconds
timeout 1 > nul
cls
echo a error has occured and junk files have been detected
echo delleting them in 3 seconds
timeout 1 > nul
cls
echo a error has occured and junk files have been detected
echo delleting them in 2 seconds
timeout 1 > nul
cls
echo a error has occured and junk files have been detected
echo delleting them in 1 seconds
timeout 1 > nul
del admin.noadmin
cls
echo they have been delleted. . .
timeout 1 > nul
goto q

:exit
:q
exit