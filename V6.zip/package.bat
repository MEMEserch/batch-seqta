@echo off
color 0a
for %%f in (*.dev) do (
goto run
)
title skill issue
echo you do not have the permitions to run this file
echo press any key to exit. . .
pause > nul
goto q
:run
echo WARNING THIS APPLICATION WILL DELLET ALL USER DATA
echo press any key to run or close this application
pause > nul
cls
echo THIS IS THE LAST WARNING
pause > nul
echo clearing data. . .
echo ------------------
echo [][][][
echo ------------------
del url.bat
del log.log
del real.com
del mode.menuC
cls
echo clearing data. . .
echo ------------------
echo [][][][][][][][][]
echo ------------------
del mode.menuT
del real.setedup
del real.officechoice
del urlw.bat
for %%f in (*.png) do (
	del %%f
)
cls
echo clearing data. . .
echo ------------------
echo   TASK COMPLETED
echo ------------------
timeout 20 > nul
cls
echo the task has complted press any key to exit. . .
pause > nul
:q
exit