@echo off
color f0
for %%f in (*.dev) do (
	goto off
)
for %%f in (*.egg) do (
	goto egg
)

echo are you sure that you want to activate admin mode?
echo having it off protects you from accidentally damaging this application
echo.
echo.
echo.
echo.
echo.
echo press any key if yes or press x if no. . .
pause > nul
cls
echo admin_mode_HIGH >> pass.dev
echo it has been enabled
pause > nul
goto q

:off
echo are you sure that you want to deactivate admin mode?
echo having it off prevents you from doing some things
echo.
echo.
echo.
echo.
echo.
echo press any key if yes or press x if no. . .
pause > nul
for %%f in (*.dev) do (
del %%f
)
echo it has been disabled
pause > nul
goto q

:egg
echo ----------------------------------------------------------------
echo a wise man once said: who uses batch script in the big 25's. . .
echo ----------------------------------------------------------------
timeout 2 > nul
echo answer;
timeout 5 > nul
echo ME
pause > nul
for %%f in (*.egg) do (
	del %%f
)
goto q

:q
exit