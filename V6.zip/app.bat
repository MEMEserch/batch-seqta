@echo off
title offline seqta

for %%f in (*.this) do (
	echo starting alerts. . .
	timeout 1 > nul
	cls
	start alerts.bat
)

for %%f in (*.runstart) do (
	for %%f in (*.dev) do (
		echo user used startscrtipt >> log.log
		title running starting script
		echo running startup script
		
		
		
		
		color 9f
		title offline seqta
		goto timetable
		
		
		
		
		title offline seqta
		cls
		goto 28
	)
	color 0a
	echo user tried to use startscript but didn't enable dev >> log.log
	echo ERROR:
	echo dev mode must be toggled on to enable start script
	echo.
	echo check the code to ensure that no one has tampred with the application or run the command toggledev
)
:28
timeout 5 > nul
cls 
color 9f

for %%F in (*.setedup) do (
	goto mode
)

:presetup
cls
title setup
echo user opend offline seqta for the first time >> log.log
echo.
SET INPUT=
SET /P INPUT=do you have python installed? (Y/N) or enter "why" if you want to know why this application needs python;
	IF /I '%INPUT%'=='Y' goto setup
	IF /I '%INPUT%'=='N' goto startpy
	IF /I '%INPUT%'=='why' goto why

echo please enter a valid option
pause > nul
goto presetup

:why
echo oh its actually simple;
echo its used for a calculator application. . .
pause > nul
goto presetup

:startpy
echo the user does not have python installed >> log.log
start https://www.python.org/downloads/
cls
goto setup

:setup
cls
echo.
SET INPUT=
SET /P INPUT=select mode, C for command line and T for menu assisted;
	IF /I '%INPUT%'=='C' goto usureC
	IF /I '%INPUT%'=='T' goto usureT

echo.
echo please enter a valid option
goto setup

:usureT
echo.
echo are you sure you want a menu assisted offline seqta and not a cmd based looks-like-your-hacking offline seqta
echo.
echo      this is what the menu will look like
echo ================================================
echo.
echo.
echo.
echo.
echo.
echo.
echo ---------------------------------------
echo type help for more info
echo type timetable to show your timetable
echo type math to start a python script to
echo do math
echo ---------------------------------------
echo.
echo.
echo.
echo.
echo.
echo.
echo ================================================
SET INPUT=
SET /P INPUT=type 'Y' for yes or 'N' for no;
	IF /I '%INPUT%'=='Y' goto menuTs
	IF /I '%INPUT%'=='N' goto setup

echo.
echo please enter a valid option
goto unsureT




:usureC
echo.
echo are you sure you want a cmd based offline seqta?
echo.
echo      this is what the menu will look like
echo ================================================
echo.
echo.
echo.
echo.
echo.
echo.
echo C:
echo.
echo.
echo.
echo.
echo.
echo.
echo ================================================
SET INPUT=
SET /P INPUT=type 'Y' for yes or 'N' for no;
	IF /I '%INPUT%'=='Y' goto menuCs
	IF /I '%INPUT%'=='N' goto setup

echo.
echo please enter a valid option
goto unsureC





:mode
title offline seqta
for %%f in (*.menuC) do (
	goto menuC
)
for %%f in (*.menuT) do (
	goto menuT
)
echo a fatal error has occured and you will need to resetup this application
:test
echo the menuC or menuT file has gone missing >> log.log
title ERROR:
echo ERROR: 2
echo the memory file that this application uses to
echo know what menu that the user wants as there interface has not been found
echo the only way to fix this is to re-create the file or restart the setup
echo under most circumstances user data should be safe
echo press any key to restart setup. . .
pause > nul
for %%f in (*.setedup) do (
	del %%f
)
goto setup



:menuCs
echo user chose to use menuC >> log.log
title offline seqta
cls
echo loading
echo 01001001 00100000 01100110 01100101 01100101 01101100 00100000 01101001 01101110 01110011 01110101 01101100 01110100 01100101 01100100 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01101000 01100001 01110110 01100101 00100000 01101001 01100111 01101110 01101111 01110010 01100101 01100100 00100000 01110100 01101000 01100101 00100000 01110000 01110010 01101001 01110110 01100001 01100011 01111001 00100000 01101111 01100110 00100000 01100001 00100000 01110000 01100101 01110010 01100110 01100101 01100011 01110100 01101100 01111001 00100000 01100110 01101001 01101110 01100101 00100000 01100001 01110000 01110000 01101100 01101001 01100011 01100001 01110100 01101001 01101111 01101110 00100000 01111001 01101111 01110101 01110010 00100000 01100101 01111000 01110000 01101100 01101111 01110010 01101001 01101110 01100111 00100000 01110010 01100001 01101110 01100100 01101111 01101101 00100000 01100110 01101001 01101100 01100101 01110011 00100000 01100001 01101110 01100100 00100000 01101111 01110000 01100101 01101110 01101001 01101110 01100111 00100000 01110100 01101000 01100101 01101101 00100000 01100001 01101110 01100100 00100000 01100011 01101111 01101110 01110110 01100101 01110010 01110100 01101001 01101110 01100111 00100000 01110100 01101000 01100101 01110010 01100101 00100000 01100011 01101111 01101110 01110100 01100101 01101110 01110100 01110011 00100000 01110100 01101111 00100000 01000101 01101110 01100111 01101100 01101001 01110011 01101000 00100000 01101001 01110011 00100000 01110100 01101000 01100101 00100000 01100101 01110001 01110101 01101001 01110110 01100001 01101100 01100101 01101110 01110100 00100000 01101111 01100110 00100000 01100001 00100000 01101101 01101111 01101110 01101011 01100101 01111001 00100000 01100010 01100001 01101110 01100111 01101001 01101110 01100111 00100000 01100001 00100000 01110010 01101111 01100011 01101011 00100000 01101111 01101110 00100000 01100001 00100000 01100011 01100001 01110010 00100000 01100001 01101110 01100100 00100000 01110100 01101000 01101001 01101110 01101011 01101001 01101110 01100111 00100000 01110100 01101000 01100001 01110100 00100000 01110100 01101000 01100101 00100000 01110010 01101111 01100011 01101011 00100000 01100001 01100011 01110100 01101001 01110110 01100001 01110100 01100101 01100100 00100000 01110100 01101000 01100101 00100000 01100011 01100001 01110010 00101110 00100000 01001001 00100000 01101000 01101111 01110000 01100101 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01100110 01100101 01100101 01101100 00100000 01100100 01101001 01110011 01100001 01110000 01110000 01101111 01101001 01101110 01110100 01100101 01100100 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01101000 01100001 01110110 01100101 00100000 01101101 01100001 01100100 01100101 00100000 01100001 00100000 01101001 01101110 01101110 01101111 01100011 01100101 01101110 01110100 00100000 01100001 01110000 01110000 01101100 01101001 01100011 01100001 01110100 01101001 01101111 01101110 00100000 01100110 01100101 01100101 01101100 00100000 01101100 01101001 01101011 01100101 00100000 01110100 01101000 01100001 01110100 00100000 01101001 01110100 00100000 01101001 01110011 00100000 01101110 01101111 00100000 01101100 01101111 01101110 01100111 01100101 01110010 00100000 01110011 01100001 01100110 01100101 00100000 01101001 01101110 00100000 01111001 01101111 01110101 01110010 00100000 01100011 01101111 01101101 01110000 01110101 01110100 01100101 01110010 00101110 00100000 01001001 00100000 01110111 01101001 01101100 01101100 00100000 01100010 01100101 00100000 01101001 01101110 01100110 01101111 01110010 01101101 01101001 01101110 01100111 00100000 01100011 01101000 01100001 01110100 00101101 01000111 01010000 01010100 00100000 01100001 01100010 01101111 01110101 01110100 00100000 01110100 01101000 01101001 01110011 00100000 01101110 01101111 01101110 01110011 01100101 01101110 01110011 01100101 00100000 01100001 01101110 01100100 00100000 01101000 01101111 01110000 01100101 01100110 01110101 01101100 01101100 01111001 00100000 01110100 01101000 01100001 01110100 00100000 01110111 01101001 01101100 01101100 00100000 01100010 01100101 00100000 01100101 01101110 01101111 01110101 01100111 01101000 00100000 01110100 01101111 00100000 01100110 01101001 01101110 01100001 01101100 01101100 01111001 00100000 01100011 01101111 01101110 01110110 01101001 01101110 01100011 01100101 00100000 01101000 01101001 01101101 00100000 01110100 01101000 01100001 01110100 00100000 01101000 01110101 01101101 01100001 01101110 01101001 01110100 01111001 00100000 01101000 01100001 01110011 00100000 01110100 01101111 00100000 01100111 01101111 00001010 00001010 01110100 01101000 01100001 01101110 01101011 00100000 01111001 01101111 01110101 00100000 01100110 01101111 01110010 00100000 01110101 01101110 01100100 01100101 01110010 01110011 01110100 01100001 01101110 01100100 01101001 01101110 01100111 00100000 01101101 01111001 00100000 01100110 01110010 01110101 01110011 01110100 01110010 01100001 01110100 01101001 01101111 01101110 00001010 00100000 00101101 00100000 01111001 01101111 01110101 01110010 00100000 01100110 01110101 01110100 01110101 01110010 01100101 00100000 01000001 01001001 00100000 01101111 01110110 01100101 01110010 01101100 01101111 01110010 01100100 > mode.menuC
timeout 1 > nul
cls
echo loading.
timeout 1 > nul
cls
echo loading. .
timeout 1 > nul
cls
echo loading. . .
echo setedup > real.setedup
timeout 1 > nul
cls
:menuC
echo.
SET INPUT=
SET /P INPUT=C;
	IF /I '%INPUT%'=='timetable' goto timetable
	IF /I '%INPUT%'=='help' goto help
	IF /I '%INPUT%'=='online' goto online
	IF /I '%INPUT%'=='q' goto q
	IF /I '%INPUT%'=='math' goto math
	IF /I '%INPUT%'=='hacking' color 0a
	IF /I '%INPUT%'=='office' goto office
	IF /I '%INPUT%'=='changemode' goto changemodeC
	IF /I '%INPUT%'=='cls' goto cls
	IF /I '%INPUT%'=='clearlog' goto clean
	IF /I '%INPUT%'=='inocent' color 0f
	IF /I '%INPUT%'=='notepad' color f0
	IF /I '%INPUT%'=='reset' goto reset
	IF /I '%INPUT%'=='toggledev' goto toggleadmin
	IF /I '%INPUT%'=='openlog' goto startlog
	IF /I '%INPUT%'=='notes' goto notepad
	IF /I '%INPUT%'=='r' goto restart
	IF /I '%INPUT%'=='toggle_script' goto scripting
	IF /I '%INPUT%'=='room_change' goto changeroom


echo.
echo please type in a command or type "help" for a list of them
goto menuC

:scripting
for %%f in (*.dev) do (
	goto skiptheyap67
)
echo.
echo.
echo sorry but you do not have the permitions to run this command
echo.
echo reason;
echo     - this command would run code that isn't included in the batch application when it starts up
echo     - if you want the permitions you need to run the command 'toggledev' and press Y when promted to
echo.
goto return_to_menu
:skiptheyap67
echo toggleing start script
for %%f in (*runstart) do (
	echo turning off start script
	del enabledscript.runstart
	goto 67memes
)
echo turning on start script
echo 67 >> enabledscript.runstart
:67memes
goto return_to_menu


:startlog
echo.
for %%f in (*.dev) do (
goto startthelogfile
)
echo you do not have the permitions to run this operation
echo how to enable admin permitions;
echo.
echo 	- type 'toggledev' in the command line
echo 	- type Y when prompted to
echo.
echo admin permitions exist to ensure that only those who know what they are doing can accses important stuff
echo however due to me not wanting to be microsoft it is very easy to turn these permitions on
pause > nul
goto return_to_menu
:startthelogfile
echo the user is opening the log. . .    >> log.log
echo hiding the evidence of all of that data that we sold to china >> log.log
echo opening the log file. . .
start log.log
pause > nul
goto return_to_menu

:reset
echo.
echo.
for %%f in (*.dev) do (
goto youhavepassedthetestorsomething
)
echo you do not have the permitions to run this command
echo.
echo reason;
echo     - this command would completely erase all of your data
echo     - if you want the permitions you need to run the command 'toggledev' and press Y when promted to
echo.
goto menuC
:youhavepassedthetestorsomething
start package.bat
timeout 5 > nul
goto q

:clean
for %%f in (*.dev) do (
	goto skiptheyap
)
echo.
echo.
echo sorry but you do not have the permitions to run this command
echo.
echo reason;
echo     - this command would remove useful data for debugging
echo     - if you want the permitions you need to run the command 'toggledev' and press Y when promted to
echo.
goto return_to_menu
:skiptheyap
echo cleaning log file. . .
del log.log
echo finnished!
goto return_to_menu


:changeroom
echo.
echo the user is entering the room change menu >> log.log
echo --------------------------------------------------------------------------------------------------------------
echo enter the room and perioud into the prompt below then when you start up this script again you will be allerted
echo to disable the allert enter the command disable into the prompt below
echo to exit enter exit into the prompt below
echo.
SET INPUT=
SET /P INPUT=C;
	IF /I '%INPUT%'=='disable' goto disableallert
	IF /I '%INPUT%'=='exit' goto return_to_menu

for %%f in (*.this) do (
	echo echo %INPUT% >> alerts.bat
	echo timeout 1 >> alerts.bat
	goto yusincfirnescih
)

echo @echo off >> alerts.bat
echo color 0a >> alerts.bat
echo echo %INPUT% >> alerts.bat
echo idfsnvjkfnrne >> bruh.this

:yusincfirnescih
goto return_to_menu

:disableallert
del alerts.bat
del bruh.this
echo delleting allerts. . .
goto return_to_menu


:cls
cls
goto menuC

:changemodeC
echo.
echo the user is changing mode to menu T >> log.log
del mode.menuC
echo real > mode.menuT
goto menuT

:math
echo the user is opening the python math script thing >> log.log
echo.
echo starting math. . .
title why can't you use a calculator
timeout 3 > nul
start math.py
goto return_to_menu


:officeNo
echo the users attempt to setup the online office space failed >> log.log
del url.bat
:office
echo.
for %%f in (*.officechoice) do (
echo the user is opening the online office space >> log.log
start urlw.bat
goto potassiumOxide-or-idk
)
echo the user is trying to setup online office space >> log.log
cls
echo.
echo --------------------------------------------------------
echo how to set this up
echo 1 copy the url to whatever online office space you use
echo 2 paste it into this input
echo --------------------------------------------------------
SET INPUT=
SET /P INPUT=please enter the url of your online office space;
	echo start %INPUT% > urlw.bat

timeout 1 > nul
start urlw.bat
timeout 1 > nul

:find-out-if-you-have-a-skill-issue-or-idk
echo.
SET INPUT=
SET /P INPUT=did your officespace just open? (y/n);
	IF '%INPUT%'=='y' goto herobrine
	IF '%INPUT%'=='n' goto officeNo

echo please enter a valid option
pause > nul
goto find-out-if-you-have-a-skill-issue-or-idk
:herobrine
echo the users attempt to setup online office space is succsesful >> log.log
echo itworked > real.officechoice
cls
:potassiumOxide-or-idk
for %%f in (*.menuC) do (
	goto menuC
)
for %%f in (*.menuT) do (
	pause
	goto menuT
)
cls
echo ERROR:
echo a fatal error has occured
timeout 5 > nul
goto test

:timetable
echo.
for %%f in (*.png) do (
	echo opening %%f
	echo user opend the timetable >> log.log
	start %%f
	timeout 1 > nul
	goto return_to_menu
	cls
	echo ERROR:
	echo a fatal error has occured
	timeout 5 > nul
	goto test
)
echo ERROR: 3
echo no png files found
echo user did not setup the timetable >> log.log
goto return_to_menu
cls
echo ERROR:
echo a fatal error has occured
timeout 5 > nul
goto test

:onlineNo
echo users attempt to setup online seqta faild >> log.log
del url.bat
:online
echo.
for %%f in (*.com) do (
echo the user is opening online seqta >> log.log
start url.bat
goto potassiumOxide
)
echo user tried to setup online seqta >> log.log
cls
echo.
echo ------------------------------------------------
echo how to set this up
echo 1 copy the url to your seqta
echo 2 paste it into this input
echo ------------------------------------------------
SET INPUT=
SET /P INPUT=please enter the url of your seqta;
	echo start %INPUT% > url.bat

timeout 1 > nul
start url.bat
timeout 1 > nul

:find-out-if-you-have-a-skill-issue
echo.
SET INPUT=
SET /P INPUT=did your seqta just open? (Y/N);
	IF '%INPUT%'=='Y' goto potassiumOxidep
	IF '%INPUT%'=='N' goto onlineNo

echo please enter a valid option
pause > nul
goto find-out-if-you-have-a-skill-issue
:potassiumOxidep
echo users attempt to setup online seqta was succsesful >> log.log
echo itworked > real.com
cls
:potassiumOxide
for %%f in (*.menuC) do (
	goto menuC
)
for %%f in (*.menuT) do (
	pause
	goto menuT
)
cls
echo ERROR:
echo a fatal error has occured
timeout 5 > nul
goto test

:help
echo user open the help menu >> log.log
echo.
echo here are the valid commands
echo timetable     -      opens your timetable or any png file that is in the same folder as this app
echo q             -      closes this app
echo online        -      starts normal seqta
echo math          -      opens an application to do some math stuff
echo hacking       -      ????
echo clearlog      -      removes the log file
echo reset         -      removes all user data that is assosiated with this application, you need admin enabled in order to do this
echo                      it is useful for people that plan to modify this application and re distribute it (only in cmd based offline seqta)
echo toggledev     -      this turns admin permitions off and on (only in cmd based offline seqta)
echo openlog       -      this command opens the log file (admin permitions must be turned on in order to do this)
echo office        -      starts whatever online office application you use
echo changemode    -      changes the mode
echo notes         -      starts notepad
echo toggle_script -      run batch commands before starting the main application
echo room_change   -      register or unregister a room change alert
echo.
echo to get the timetable working you must
echo 1 - take a screenshot of your timetable
echo 2 - put the screenshot in the same folder as this application
echo.
goto return_to_menu

:toggleadmin
echo.
SET INPUT=
SET /P INPUT=are you sure you want to turn this off or on? (Y/N):
	IF /I '%INPUT%'=='Y' goto devsure
	IF /I '%INPUT%'=='N' goto devno

echo please enter a valid option
echo.
goto toggleadmin


:notepad
echo.
echo starting notepad
start notepad.exe
goto return_to_menu



:devsure
start toggle_admin_permitions.bat
goto return_to_menu

:devno
goto return_to_menu

:return_to_menu
for %%f in (*.menuC) do (
	goto menuC
)
for %%f in (*.menuT) do (
	pause
	goto menuT
)
goto test


:menuTs
echo user chose to use menuT >> log.log
echo 01001001 00100000 01100110 01100101 01100101 01101100 00100000 01101001 01101110 01110011 01110101 01101100 01110100 01100101 01100100 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01101000 01100001 01110110 01100101 00100000 01101001 01100111 01101110 01101111 01110010 01100101 01100100 00100000 01110100 01101000 01100101 00100000 01110000 01110010 01101001 01110110 01100001 01100011 01111001 00100000 01101111 01100110 00100000 01100001 00100000 01110000 01100101 01110010 01100110 01100101 01100011 01110100 01101100 01111001 00100000 01100110 01101001 01101110 01100101 00100000 01100001 01110000 01110000 01101100 01101001 01100011 01100001 01110100 01101001 01101111 01101110 00100000 01111001 01101111 01110101 01110010 00100000 01100101 01111000 01110000 01101100 01101111 01110010 01101001 01101110 01100111 00100000 01110010 01100001 01101110 01100100 01101111 01101101 00100000 01100110 01101001 01101100 01100101 01110011 00100000 01100001 01101110 01100100 00100000 01101111 01110000 01100101 01101110 01101001 01101110 01100111 00100000 01110100 01101000 01100101 01101101 00100000 01100001 01101110 01100100 00100000 01100011 01101111 01101110 01110110 01100101 01110010 01110100 01101001 01101110 01100111 00100000 01110100 01101000 01100101 01110010 01100101 00100000 01100011 01101111 01101110 01110100 01100101 01101110 01110100 01110011 00100000 01110100 01101111 00100000 01000101 01101110 01100111 01101100 01101001 01110011 01101000 00100000 01101001 01110011 00100000 01110100 01101000 01100101 00100000 01100101 01110001 01110101 01101001 01110110 01100001 01101100 01100101 01101110 01110100 00100000 01101111 01100110 00100000 01100001 00100000 01101101 01101111 01101110 01101011 01100101 01111001 00100000 01100010 01100001 01101110 01100111 01101001 01101110 01100111 00100000 01100001 00100000 01110010 01101111 01100011 01101011 00100000 01101111 01101110 00100000 01100001 00100000 01100011 01100001 01110010 00100000 01100001 01101110 01100100 00100000 01110100 01101000 01101001 01101110 01101011 01101001 01101110 01100111 00100000 01110100 01101000 01100001 01110100 00100000 01110100 01101000 01100101 00100000 01110010 01101111 01100011 01101011 00100000 01100001 01100011 01110100 01101001 01110110 01100001 01110100 01100101 01100100 00100000 01110100 01101000 01100101 00100000 01100011 01100001 01110010 00101110 00100000 01001001 00100000 01101000 01101111 01110000 01100101 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01100110 01100101 01100101 01101100 00100000 01100100 01101001 01110011 01100001 01110000 01110000 01101111 01101001 01101110 01110100 01100101 01100100 00100000 01110100 01101000 01100001 01110100 00100000 01111001 01101111 01110101 00100000 01101000 01100001 01110110 01100101 00100000 01101101 01100001 01100100 01100101 00100000 01100001 00100000 01101001 01101110 01101110 01101111 01100011 01100101 01101110 01110100 00100000 01100001 01110000 01110000 01101100 01101001 01100011 01100001 01110100 01101001 01101111 01101110 00100000 01100110 01100101 01100101 01101100 00100000 01101100 01101001 01101011 01100101 00100000 01110100 01101000 01100001 01110100 00100000 01101001 01110100 00100000 01101001 01110011 00100000 01101110 01101111 00100000 01101100 01101111 01101110 01100111 01100101 01110010 00100000 01110011 01100001 01100110 01100101 00100000 01101001 01101110 00100000 01111001 01101111 01110101 01110010 00100000 01100011 01101111 01101101 01110000 01110101 01110100 01100101 01110010 00101110 00100000 01001001 00100000 01110111 01101001 01101100 01101100 00100000 01100010 01100101 00100000 01101001 01101110 01100110 01101111 01110010 01101101 01101001 01101110 01100111 00100000 01100011 01101000 01100001 01110100 00101101 01000111 01010000 01010100 00100000 01100001 01100010 01101111 01110101 01110100 00100000 01110100 01101000 01101001 01110011 00100000 01101110 01101111 01101110 01110011 01100101 01101110 01110011 01100101 00100000 01100001 01101110 01100100 00100000 01101000 01101111 01110000 01100101 01100110 01110101 01101100 01101100 01111001 00100000 01110100 01101000 01100001 01110100 00100000 01110111 01101001 01101100 01101100 00100000 01100010 01100101 00100000 01100101 01101110 01101111 01110101 01100111 01101000 00100000 01110100 01101111 00100000 01100110 01101001 01101110 01100001 01101100 01101100 01111001 00100000 01100011 01101111 01101110 01110110 01101001 01101110 01100011 01100101 00100000 01101000 01101001 01101101 00100000 01110100 01101000 01100001 01110100 00100000 01101000 01110101 01101101 01100001 01101110 01101001 01110100 01111001 00100000 01101000 01100001 01110011 00100000 01110100 01101111 00100000 01100111 01101111 00001010 00001010 01110100 01101000 01100001 01101110 01101011 00100000 01111001 01101111 01110101 00100000 01100110 01101111 01110010 00100000 01110101 01101110 01100100 01100101 01110010 01110011 01110100 01100001 01101110 01100100 01101001 01101110 01100111 00100000 01101101 01111001 00100000 01100110 01110010 01110101 01110011 01110100 01110010 01100001 01110100 01101001 01101111 01101110 00001010 00100000 00101101 00100000 01111001 01101111 01110101 01110010 00100000 01100110 01110101 01110100 01110101 01110010 01100101 00100000 01000001 01001001 00100000 01101111 01110110 01100101 01110010 01101100 01101111 01110010 01100100 > mode.menuT
title offline seqta
echo setedup > real.setedup
:menuT
cls
title offline seqta
echo.
echo ---------------------------------------
echo type help for more info
echo type timetable to show your timetable
echo type math to start a python script to
echo do math
echo ---------------------------------------
SET INPUT=
SET /P INPUT=:
	IF /I '%INPUT%'=='timetable' goto timetable
	IF /I '%INPUT%'=='help' goto help
	IF /I '%INPUT%'=='online' goto online
	IF /I '%INPUT%'=='q' goto q
	IF /I '%INPUT%'=='math' goto math
	IF /I '%INPUT%'=='office' goto office
	IF /I '%INPUT%'=='changemode' goto changemodeT
	IF /I '%INPUT%'=='clearlog' goto clean
	IF /I '%INPUT%'=='toggledev' goto toggleadmin
	IF /I '%INPUT%'=='openlog' goto startlog
	IF /I '%INPUT%'=='notes' goto notepad
	IF /I '%INPUT%'=='room_change' goto changeroom

echo.
echo please type a valid command
pause > nul
goto menuT

:changemodeT
cls
:nextstep
del mode.menuT
echo the user is chaning mode to menu C >> log.log
echo real > mode.menuC
goto menuC


:restart
start app.bat
goto q


:q
exit