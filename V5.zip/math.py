import math

def pythag():
    print(".")
    print("-------------------- pythagoris menu --------------------")
    print(".")
    print("1 - solving for C")
    print("2 - solving for A or B")
    print(".")
    print("----------------------------------------------------------")
    userinput = float(input("enter the option here ---->"))
    if userinput == 1:
        print("     __________")
        print("C = /(A^2 + B^2)")
        print(".")
        A = float(input("what is the value of A -->"))
        B = float(input("what is the value of B -->"))
        C = 0
        C = ((A**2)+(B**2))**0.5
        print(".")
        print("C is equall to ", C)
        startup()
    if userinput == 2:
        print("     __________")
        print("A = /(C^2 - B^2)")
        print(".")
        C = float(input("what is the value of C -->"))
        B = float(input("what is the value of B -->"))
        A = 0
        A = ((C**2)-(B**2))**0.5
        print(".")
        print("A is equall to ", A)
        startup()
    print("please enter a valid option")
    pythag()

def quadratic():
    print(".")
    print("this is the quadratics and linear equations menu")
    print("-------------------------------------------------")
    print(".")
    print("1 - linear equations")
    print("2 - quadratics")
    print("3 - back to main menu")
    print(".")
    print("-------------------------------------------------")
    userinput = 0
    userinput = float(input("enter the option here -->"))
    print(".")
    if userinput == 1:
        print(".")
        print("Y = MX+C")
        print(".")
        M = float(input("please enter the value of M"))
        X = float(input("please enter the starting value of X"))
        C = float(input("please enter the value of C"))
        orX = X
        Yzero = 0
        Yone = 0
        Ytwo = 0
        Tthree = 0
        Yfour = 0
        Yfive = 0
        print("working. . .")
        Yzero = M*X+C
        X = X+1
        Yone = M*X+C
        X = X+1
        Ytwo = M*X+C
        X = X+1
        Ythree = M*X+C
        X = X+1
        Yfour = M*X+C
        X = X+1
        Yfive = M*X+C
        X = X+1
        X = orX
        print("resaults")
        print("---------------------------")
        print("Y            |            X")
        print("---------------------------")
        print(Yzero,       "|",           X)
        X = X+1
        print(Yone,        "|",           X)
        X = X+1
        print(Ytwo,        "|",           X)
        X = X+1
        print(Ythree,      "|",           X)
        X = X+1
        print(Yfour,       "|",           X)
        X = X+1
        print(Yfive,       "|",           X)
        X = X+1
        print("---------------------------")
        startup()
    if userinput == 2:
        print("equation being used  ax^2 + bx + c = y")
        a = 0
        b = 0
        c = 0
        a = float(input("please enter the value of a -->"))
        b = float(input("please enter the value of b -->"))
        c = float(input("please enter the value of c -->"))
        print("doing math. . .")
        print(".")
        print("Y       |         X")
        X = -6
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)        
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)
        X = X+1
        Y = (a*X**2)+(b*X)+c
        print(Y,"      |       ", X)   
        startup()
    if userinput == 3:
        startup()
    input("press any key to continue")
    quadratic()

def geomatre():
    print(".")
    print("---------------------------------------------------------")
    print(".")
    print("1 - volume of a cube")
    print("2 - area of a square")
    print("3 - volume of a cylinder")
    print("4 - back to menu")
    print("5 - perimiter of a square")
    print(".")
    print("---------------------------------------------------------")
    userinput = float(input("enter a option -->"))
    print(".")
    if userinput == 1:
        U = 0
        L = 0
        W = 0
        H = 0
        U = input("what unit am I working with -->")
        L = float(input("please enter the length of the cube -->"))
        W = float(input("please enter the width of the cube -->"))
        H = float(input("please enter the hight of the cube -->"))
        A = 0
        A = L*W*H
        print(".")
        print("volume = ", A, U, "^2")
        geomatre()
    if userinput == 2:
        L = 0
        W = 0
        A = 0
        U = 0
        U = input("what unit am I working with -->")
        L = float(input("please enter the length of the square -->"))
        W = float(input("please enter the width of the square -->"))
        A = 0
        A = L*W
        print(".")
        print("area = ", A, U)
        geomatre()
    if userinput == 3:
        PI = 3.14159
        H = 0
        D = 0
        U = 0
        U = input("what unit am I working with -->")
        D = float(input("what is the diamiter of the cylinder -->"))
        H = float(input("what is the hight of the cylinder -->"))
        A = 0
        A = D/2
        A = (PI*A**2)*H
        print(".")
        print("volume = ", A, U, "^2")
        geomatre()
    if userinput == 4:
        startup()
    if userinput == 5:
        L = 0
        W = 0
        U = input("what units am I working with -->")
        L = float(input("what is the squares length -->"))
        W = float(input("what is the squares width -->"))
        A = 0
        A = U+U+L+L
        print("the perimter of the square is", A, U)
        
        
def startup():
    print(".")
    print("this is a aplication for doing math things to make math class simpler")
    print("---------------------------------------------------------------------")
    print(".")
    print("1 - pythagoris")
    print("2 - quadratic and linear equations")
    print("3 - geomatre")
    print("4 - skill issue")
    print("q - quit")
    print(".")
    print("---------------------------------------------------------------------")
    userinput = float(input("enter option here -->"))
    print(".")
    if userinput == 1:
        pythag()
    if userinput == 2:
        quadratic()
    if userinput == 4:
        print("thats really sad")
        startup()
    if userinput == 3:
        geomatre()
    if userinput == 42:
        print("that is the meaning of life, the univers and everything")
    print("please enter a valid option")
    startup()



startup()
