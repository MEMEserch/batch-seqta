title linksave V0.0.1
@ECHO OFF
echo the user opened linksave >> log.log ::log this because why the hell not

::if you want to add code that will run on startup add it here



::anyway now you get to look at spegetti code
cd linksave

cls

for %%f in (*.home) do ( ::detects if the file for the home directory exsists
	goto skiptheyapsmh
)

::informs the user and adds the file if its missing
echo your missing a few files so I am going to add them . . .

mkdir linksave
cd linksave

echo rude to view the files of a harmless aplication > home.home
timeout 1 > nul
cls

::I'm not commenting on this bit so work it out yourself
:skiptheyapsmh
cls
color f0
echo welcome to linksave
echo type HELP for a list of commands
echo.
:menu
echo.
SET INPUT=
SET /P INPUT=C;
	IF /I '%INPUT%'=='HELP' goto commands
	IF /I '%INPUT%'=='savesession' goto savesession
	IF /I '%INPUT%'=='loadsession' goto load
	IF /I '%INPUT%'=='delletesession' goto dellete
	IF /I '%INPUT%'=='listsessions' goto list
	IF /I '%INPUT%'=='addtosession' goto add
	IF /I '%INPUT%'=='addfolder' goto bruh
	IF /I '%INPUT%'=='sellectfolder' goto NORDVPN
	IF /I '%INPUT%'=='exitfolder' goto SUBSCRIBE
	IF /I '%INPUT%'=='cls' goto clear
	IF /I '%INPUT%'=='exit' goto q

echo.
echo please type in a valid command
goto menu

:SUBSCRIBE
echo.
for %%f in (*.home) do (
	echo sorry but your already in the home directory of this application exiting the home directory can lead to organisational issues and potental damage to the application
	goto menu
)
echo leaving folder. . .
cd ..
goto menu

:nomenu
echo.
echo sorry but I don't like you
goto menu

:NORDVPN
echo.
SET INPUT5=
SET /P INPUT5=folder name? 
	IF /I '%INPUT5%'=='app' goto menu
	IF /I '%INPUT5%'=='..' goto nomenu

echo entering the directory %INPUT5%
cd %INPUT5%
goto menu

:bruh
echo.
echo unforunately this feature does not work as of right now
goto notavaliable
echo.
SET INPUT5=
SET /P INPUT5=folder name? 
	IF /I '%INPUT5%'=='app' goto menu

echo made the directory %INPUT5%
mkdir %INPUT5%
:notavaliable
goto menu

:add
echo.
SET INPUT5=
SET /P INPUT5=enter the name of the session, do not include the .bat file extension;
	IF /I '%INPUT5%'=='app' goto menu

:additionallink
echo.
SET INPUT6=
SET /P INPUT6=enter links, type Q to exit;;
	IF /I '%INPUT6%'=='Q' goto menu

echo.
echo start %INPUT6% >> %INPUT5%.bat
echo if there is text ontop of this line then the writing has failed
goto additionallink

:clear
cls
goto menu

:list
echo.
dir
goto menu

:dellete
echo.
SET INPUT5=
SET /P INPUT5=enter the name of the session, do not include the .bat file extension; 
	IF /I '%INPUT5%'=='app' goto menu
	
del %INPUT5%.bat
echo loading. . .
goto menu


:load
echo.
dir
echo.
SET INPUT5=
SET /P INPUT5=enter the name of the session, do not include the .bat file extension; 
start %INPUT5%.bat
echo loading. . .
goto menu


:savesession
echo.
SET INPUT5=
SET /P INPUT5=enter the name of the session;
echo @ECHO OFF >> %INPUT5%.bat
:sessionsavingmenu
echo.
SET INPUT=
SET /P INPUT=enter links, type Q to exit;
	IF /I '%INPUT%'=='Q' goto menu
	
echo start %INPUT% >> %INPUT5%.bat
goto sessionsavingmenu

:commands
echo.
echo savesession         -         this command begins the prosses of saving links the result is a saved session
echo loadsession         -         this command loads a session it will also run the list session function
echo delletesession      -         this command delletes a session to save disk space
echo listsessions        -         this command lits the names of active sessions
echo exit                -         this command closes the application
echo cls                 -         this command clears the screen
echo addfolder           -         this command adds an additional folder for organisation
echo sellectfolder       -         this command sellects the working directory for this application
echo exitfolder          -         this command leaves a sellected folder
goto menu

:q
exit